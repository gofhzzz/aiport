
import pytorch_lightning as pl
from torch.utils.data import random_split, Dataset, DataLoader
from torchvision.transforms import *

from aiscli.datasets import load_dataset
from aiscli.utils import get_kwargs_keys_from_dict

DATASET_NAME = 'SST2'
DATASET_KWARGS = {'path': 's3://dm-datasets/public/SST2.zip', 'item_loader_cls': 'SST2ItemLoader', 'tokenizer': 'bert_tokenizer_base_uncased', 'valid_ratio': 0.2, 'shuffle': True}
DATAMODULE_KWARGS = {}
DATALOADER_KWARGS = {'batch_size': 32, 'shuffle': True, 'num_workers': 0, 'pin_memory': False, 'drop_last': False}
AUGMENTATION = Compose(None)
TRAIN_TRANSFORM = Compose([None])
VAL_TRANSFORM = Compose([None])
TEST_TRANSFORM = Compose([None])

class UserDataModule(pl.LightningDataModule):

    def __init__(self):
        super().__init__(
            train_transforms = TRAIN_TRANSFORM,
            val_transforms = VAL_TRANSFORM,
            test_transforms = TEST_TRANSFORM,
            **DATAMODULE_KWARGS
            )
        
    def prepare_data(self):
        load_dataset(DATASET_NAME, DATASET_KWARGS, download=True, split='train', credential_path='./credential.json')

    def setup(self, stage=None):
        if stage == "fit" or stage is None:
            self.dataset_train = load_dataset(DATASET_NAME, DATASET_KWARGS, split='train', augmentations=AUGMENTATION, transform=TRAIN_TRANSFORM)
            self.dataset_val = load_dataset(DATASET_NAME, DATASET_KWARGS, split='val', transform=VAL_TRANSFORM)
            #self.dims = tuple(self.dataset_train[0][0].shape)

        if stage == "test" or stage is None:
            self.dataset_test = load_dataset(DATASET_NAME, DATASET_KWARGS, split='test', transform=TRAIN_TRANSFORM)
            #self.dims = tuple(self.dataset_test[0][0].shape)

    def train_dataloader(self, *args, **kwargs):
        return self._data_loader(self.dataset_train)

    def val_dataloader(self, *args, **kwargs):
        return self._data_loader(self.dataset_val)

    def test_dataloader(self, *args, **kwargs):
        return self._data_loader(self.dataset_test)

    def _data_loader(self, dataset: Dataset, shuffle: bool = False) -> DataLoader:
        loader_kwargs = get_kwargs_keys_from_dict(DATALOADER_KWARGS, DataLoader.__init__)
        return DataLoader(dataset, **loader_kwargs)
