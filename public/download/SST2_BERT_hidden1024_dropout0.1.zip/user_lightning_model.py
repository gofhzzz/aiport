
import torch
import torch.nn.functional as F

import pytorch_lightning as pl

from user_model import UserModel
from sklearn.metrics import classification_report

class UserLightningModule(pl.LightningModule):

    def __init__(self):
        super().__init__()
        self.model = UserModel()

    def forward(self, **kwargs):
        return self.model.forward(**kwargs)

    def training_step(self, train_batch, batch_idx):
          x, y = train_batch
          logits = self.forward(**x)
          loss = self.calculate_loss(logits, y)

          logs = {'train_loss': loss}
          return {'loss': loss, 'log': logs}

    def validation_step(self, val_batch, batch_idx):
          x, y = val_batch
          logits = self.forward(**x)
          loss = self.calculate_loss(logits, y)

          return {'val_loss': loss}

    def validation_epoch_end(self, outputs):
          avg_loss = torch.stack([x['val_loss'] for x in outputs]).mean()
          tensorboard_logs = {'val_loss': avg_loss}
          return {'avg_val_loss': avg_loss, 'log': tensorboard_logs}

    def calculate_loss(self, *args):
        return self.configure_loss()(*args)

    def configure_loss(self):
        return torch.nn.CrossEntropyLoss()

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), **{'lr': 0.001})
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, **{'step_size': 10, 'gamma': 0.1})
        return [optimizer], [scheduler]
    