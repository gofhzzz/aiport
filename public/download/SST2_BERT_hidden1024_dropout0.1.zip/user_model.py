
import pytorch_lightning as pl
import numpy as np
import torch
import torch.nn as nn

from torch.hub import load_state_dict_from_url
# https://github.com/codertimo/BERT-pytorch

import torch.nn as nn
import torch.nn.functional as F
import torch
import math
from transformers import BertModel, BertTokenizer
import gluonnlp as nlp
import os
# from .transformer import TransformerBlock
# from .embedding import BERTEmbedding


class BERT(nn.Module):
    def __init__(self, vocab_size=30522, hidden=768, n_layers=12, attn_heads=12, dropout=0.1):
        super().__init__()
        self.hidden = hidden
        self.n_layers = n_layers
        self.attn_heads = attn_heads

        # paper noted they used 4*hidden_size for ff_network_hidden_size
        self.feed_forward_hidden = hidden * 4

        # embedding for BERT, sum of positional, segment, token embeddings
        self.embedding = BERTEmbedding(vocab_size=vocab_size, embed_size=hidden, dropout=dropout)

        # multi-layers transformer blocks, deep network
        self.transformer_blocks = nn.ModuleList([TransformerBlock(hidden, attn_heads, hidden * 4, dropout) for _ in range(n_layers)])
        self.pooling_layer = BERTPooler(hidden=hidden)

    def forward(self, input_ids, token_type_ids, attention_mask):
        # attention masking for padded token
        # mask = torch.ByteTensor([batch_size, 1, seq_len, seq_len])
        if attention_mask == None:
            attention_mask = (input_ids > 0).unsqueeze(1).repeat(1, input_ids.size(1), 1).unsqueeze(1)
        else:
            attention_mask = (attention_mask > 0).unsqueeze(1).repeat(1, attention_mask.size(1), 1).unsqueeze(1)
        # embedding the indexed sequence to sequence of vectors
        x = self.embedding(input_ids, token_type_ids)

        # running over multiple transformer blocks
        for transformer in self.transformer_blocks:
            x = transformer.forward(x, mask)

        return x, self.pooling_layer(x)

class BERTPooler(nn.Module):
    def __init__(self, hidden):
        super().__init__()
        self.dense = nn.Linear(hidden, hidden)
        self.activation = nn.Tanh()

    def forward(self, hidden_states):
        # We "pool" the model by simply taking the hidden state corresponding
        # to the first token.
        first_token_tensor = hidden_states[:, 0]
        pooled_output = self.dense(first_token_tensor)
        pooled_output = self.activation(pooled_output)
        return pooled_output


class BERTEmbedding(nn.Module):
    def __init__(self, vocab_size, embed_size, dropout=0.1):
        super().__init__()
        self.token = TokenEmbedding(vocab_size=vocab_size, embed_size=embed_size)
        self.position = PositionalEmbedding(d_model=self.token.embedding_dim)
        self.segment = SegmentEmbedding(embed_size=self.token.embedding_dim)
        self.dropout = nn.Dropout(p=dropout)
        self.embed_size = embed_size

    def forward(self, sequence, segment_label):
        x = self.token(sequence) + self.position(sequence) + self.segment(segment_label)
        return self.dropout(x)


class TokenEmbedding(nn.Embedding):
    def __init__(self, vocab_size, embed_size=512):
        super().__init__(vocab_size, embed_size, padding_idx=0)


class PositionalEmbedding(nn.Module):
    def __init__(self, d_model, max_len=512):
        super().__init__()

        # Compute the positional encodings once in log space.
        pe = torch.zeros(max_len, d_model).float()
        pe.require_grad = False

        position = torch.arange(0, max_len).float().unsqueeze(1)
        div_term = (torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model)).exp()

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    
    def forward(self, x):
        return self.pe[:, :x.size(1)]


class SegmentEmbedding(nn.Embedding):
    def __init__(self, embed_size=512):
        super().__init__(2, embed_size) #3 , padding_idx=0에서 수정


class TransformerBlock(nn.Module):
    def __init__(self, hidden, attn_heads, feed_forward_hidden, dropout):
        super().__init__()
        self.attention = MultiHeadedAttention(h=attn_heads, d_model=hidden)
        self.feed_forward = PositionwiseFeedForward(d_model=hidden, d_ff=feed_forward_hidden, dropout=dropout)
        self.input_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.output_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x, mask):
        x = self.input_sublayer(x, lambda _x: self.attention.forward(_x, _x, _x, mask=mask))
        x = self.output_sublayer(x, self.feed_forward)
        return self.dropout(x)


class MultiHeadedAttention(nn.Module):
    def __init__(self, h, d_model, dropout=0.1):
        super().__init__()
        assert d_model % h == 0

        # We assume d_v always equals d_k
        self.d_k = d_model // h
        self.h = h

        self.linear_layers = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(3)])
        self.output_linear = nn.Linear(d_model, d_model)
        self.attention = Attention()

        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):
        batch_size = query.size(0)

        # 1) Do all the linear projections in batch from d_model => h x d_k
        query, key, value = [l(x).view(batch_size, -1, self.h, self.d_k).transpose(1,2) for l, x in zip(self.linear_layers, (query, key, value))]

        # 2) Apply attention on all the projected vectors in batch.
        x, attn = self.attention(query, key, value, mask=mask, dropout=self.dropout)

        # 3) "Concat" using a view and apply a final linear.
        x = x.transpose(1,2).contiguous().view(batch_size, -1, self.h * self.d_k)

        return self.output_linear(x)


class Attention(nn.Module):
    """
    Compute 'Scaled Dot Product Attention
    """

    def forward(self, query, key, value, mask=None, dropout=None):
        scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(query.size(-1))

        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        
        p_attn = F.softmax(scores, dim=-1)

        if dropout is not None:
            p_attn = dropout(p_attn)
        
        return torch.matmul(p_attn, value), p_attn


class SublayerConnection(nn.Module):
    """
    A residual connection followed by a layer norm.
    Note for code simplicity the norm is first as opposed to last.
    """
    def __init__(self, size, dropout):
        super().__init__()
        self.norm = LayerNorm(size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        return x + self.dropout(sublayer(self.norm(x)))


class LayerNorm(nn.Module):
    def __init__(self, features, eps=1e-6):
        super().__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2


class PositionwiseFeedForward(nn.Module):
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = GELU()
    
    def forward(self, x):
        return self.w_2(self.dropout(self.activation(self.w_1(x))))


class GELU(nn.Module):
    def forward(self, x):
        return 0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))



####### Language model #########

class BERTLM(nn.Module):
    """
    BERT Language Model
    Next Sentence Prediction Model + Masked Language Model
    """
    def __init__(self, bert, vocab_size, hidden=768, dropout=0.1):
        super().__init__()
        self.bert = bert
        self.next_sentence = NextSentencePrediction(hidden, dropout=dropout)
        self.mask_lm = MaskedLanguageModel(hidden, vocab_size, dropout=dropout)
        
    def forward(self, input_ids=None, token_type_ids=None, attention_mask=None, labels=None, is_next=None):
        output = self.bert(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
        x = output[0]
        pooled_output = output[1]
        next_sent_output, mask_lm_output = self.next_sentence(pooled_output), self.mask_lm(x)
        return next_sent_output, mask_lm_output.transpose(1,2)

        
        # loss = None
        # if labels is not None:
        #     loss_fct = nn.NLLLoss(ignore_index=0)
        #     next_loss = loss_fct(next_sent_output, is_next)
        #     mask_loss = loss_fct(mask_lm_output.transpose(1,2), labels)
        #     loss = next_loss + mask_loss

        # return loss, (next_sent_output, mask_lm_output)
        
        

class NextSentencePrediction(nn.Module):
    """
    2-class classification model: is_next, is_not_next
    """
    def __init__(self, hidden, dropout=0.1):
        """
        :param hidden: BERT model output size
        """
        super().__init__()
        self.linear = nn.Linear(hidden, 2)
        self.softmax = nn.LogSoftmax(dim=-1)
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_normal_(self.linear.weight)

    def forward(self, x):
        x = self.dropout(x)
        return self.softmax(self.linear(x))
        

class MaskedLanguageModel(nn.Module):
    """
    predicting origin token from masked input sequence
    n-class classification problem, n-class = vocab_size
    """
    def __init__(self, hidden, vocab_size, dropout=0.1):
        """
        :param hidden: output size of BERT model
        :param vocab_size: total vocab size
        """
        super().__init__()
        self.linear = nn.Linear(hidden, vocab_size)
        self.softmax = nn.LogSoftmax(dim=-1)
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_normal_(self.linear.weight)

    def forward(self, x):
        x = self.dropout(x)
        return self.softmax(self.linear(x))



##### Fine tuning model #####
'''
BERT_PRETRAINED_CONFIG_ARCHIVE_MAP = {
    "bert-base-uncased": "https://huggingface.co/bert-base-uncased/resolve/main/config.json",
    "bert-large-uncased": "https://huggingface.co/bert-large-uncased/resolve/main/config.json",
    "bert-base-cased": "https://huggingface.co/bert-base-cased/resolve/main/config.json",
    "bert-large-cased": "https://huggingface.co/bert-large-cased/resolve/main/config.json",
    "bert-base-multilingual-uncased": "https://huggingface.co/bert-base-multilingual-uncased/resolve/main/config.json",
    "bert-base-multilingual-cased": "https://huggingface.co/bert-base-multilingual-cased/resolve/main/config.json",
    "bert-base-chinese": "https://huggingface.co/bert-base-chinese/resolve/main/config.json",
    "bert-base-german-cased": "https://huggingface.co/bert-base-german-cased/resolve/main/config.json",
    "bert-large-uncased-whole-word-masking": "https://huggingface.co/bert-large-uncased-whole-word-masking/resolve/main/config.json",
    "bert-large-cased-whole-word-masking": "https://huggingface.co/bert-large-cased-whole-word-masking/resolve/main/config.json",
    "bert-large-uncased-whole-word-masking-finetuned-squad": "https://huggingface.co/bert-large-uncased-whole-word-masking-finetuned-squad/resolve/main/config.json",
    "bert-large-cased-whole-word-masking-finetuned-squad": "https://huggingface.co/bert-large-cased-whole-word-masking-finetuned-squad/resolve/main/config.json",
    "bert-base-cased-finetuned-mrpc": "https://huggingface.co/bert-base-cased-finetuned-mrpc/resolve/main/config.json",
    "bert-base-german-dbmdz-cased": "https://huggingface.co/bert-base-german-dbmdz-cased/resolve/main/config.json",
    "bert-base-german-dbmdz-uncased": "https://huggingface.co/bert-base-german-dbmdz-uncased/resolve/main/config.json",
    "cl-tohoku/bert-base-japanese": "https://huggingface.co/cl-tohoku/bert-base-japanese/resolve/main/config.json",
    "cl-tohoku/bert-base-japanese-whole-word-masking": "https://huggingface.co/cl-tohoku/bert-base-japanese-whole-word-masking/resolve/main/config.json",
    "cl-tohoku/bert-base-japanese-char": "https://huggingface.co/cl-tohoku/bert-base-japanese-char/resolve/main/config.json",
    "cl-tohoku/bert-base-japanese-char-whole-word-masking": "https://huggingface.co/cl-tohoku/bert-base-japanese-char-whole-word-masking/resolve/main/config.json",
    "TurkuNLP/bert-base-finnish-cased-v1": "https://huggingface.co/TurkuNLP/bert-base-finnish-cased-v1/resolve/main/config.json",
    "TurkuNLP/bert-base-finnish-uncased-v1": "https://huggingface.co/TurkuNLP/bert-base-finnish-uncased-v1/resolve/main/config.json",
    "wietsedv/bert-base-dutch-cased": "https://huggingface.co/wietsedv/bert-base-dutch-cased/resolve/main/config.json",
    # See all BERT models at https://huggingface.co/models?filter=bert
}
'''


class BERTClassification(nn.Module):
    def __init__(self, bert, hidden=768, num_classes=2, dropout=0.1):
        super().__init__()
        self.bert = bert
        self.num_classes = num_classes
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden, num_classes)
        nn.init.xavier_normal_(self.classifier.weight)
        
    def forward(self, 
                input_ids=None, 
                attention_mask=None,
                token_type_ids=None,
                position_ids=None,
                head_mask=None, 
                inputs_embeds=None, 
                labels=None, 
                output_attentions=None, 
                output_hidden_states=None, 
                return_dict=None
    ):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict
        )
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        return logits



class BERTSentimentAnalysis(BERTClassification):
    pass

        
        # loss = None
        # if labels is not None:
        #     if self.num_labels == 1:
        #         #  We are doing regression
        #         loss_fct = nn.MSELoss()
        #         loss = loss_fct(logits.view(-1), labels.view(-1))
        #     else:
        #         loss_fct = nn.CrossEntropyLoss()
        #         loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))

        # return loss, logits
        



class BERTQuestionAnswering(nn.Module):
    def __init__(self, bert, hidden=768, num_classes=2, dropout=0.1):
        super().__init__()
        self.bert = bert
        self.dropout = nn.Dropout(dropout)
        self.qa_outputs = nn.Linear(hidden, num_classes)
        nn.init.xavier_normal_(self.qa_outputs.weight)

    def forward(self, 
                input_ids=None, 
                attention_mask=None,
                token_type_ids=None,
                position_ids=None,
                head_mask=None, 
                inputs_embeds=None,
                labels=None, 
                start_positions=None, 
                end_positions=None, 
                output_attentions=None, 
                output_hidden_states=None, 
                return_dict=None
    ):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict
        )

        sequence_output = outputs[0]
        sequence_output = self.dropout(sequence_output)
        logits = self.qa_outputs(sequence_output)
        start_logits, end_logits = logits.split(1, dim=-1)
        start_logits = start_logits.squeeze(-1)
        end_logits = end_logits.squeeze(-1)
        return start_logits, end_logits

        
        # total_loss = None
        # if start_positions is not None and end_positions is not None:
        #     # If we are on multi-GPU, split add a dimension
        #     if len(start_positions.size()) > 1:
        #         start_positions = start_positions.squeeze(-1)
        #     if len(end_positions.size()) > 1:
        #         end_positions = end_positions.squeeze(-1)
        #     # sometimes the start/end positions are outside our model inputs, we ignore these terms
        #     ignored_index = start_logits.size(1)
        #     start_positions.clamp_(0, ignored_index)
        #     end_positions.clamp_(0, ignored_index)

        #     loss_fct = nn.CrossEntropyLoss(ignore_index=ignored_index)
        #     start_loss = loss_fct(start_logits, start_positions)
        #     end_loss = loss_fct(end_logits, end_positions)
        #     total_loss = (start_loss + end_loss) / 2

        #     return total_loss, (start_logits, end_logits)
        # else:
        #     return start_logits, end_logits
        


'''
BERT pretraind model name / BertConfig
"bert-base-cased" / vocab_size_or_config_json_file=28996, hidden_size=768, num_hidden_layers=12, num_attention_heads=12, intermediate_size=3072

"bert-base-uncased" / vocab_size_or_config_json_file=30522, hidden_size=768, num_hidden_layers=12, num_attention_heads=12, intermediate_size=3072

"bert-finance-cased" / vocab_size_or_config_json_file=28573, hidden_size=768, num_hidden_layers=12, num_attention_heads=12, intermediate_size=3072

"bert-finance-uncased" / vocab_size_or_config_json_file=30873, hidden_size=768, num_hidden_layers=12, num_attention_heads=12, intermediate_size=3072
'''



# vocab_path = "vocab/kobert_news_wiki_ko_cased-1087f8699e.spiece"
# model_path = "model/kobert_from_pretrained"
    
def bert_base_uncased():
    return BertModel.from_pretrained('bert-base-uncased')

def bert_base_cased():
    return BertModel.from_pretrained('bert-base-cased')

def bert_large_uncased():
    return BertModel.from_pretrained('bert-large-uncased')

def bert_large_cased():
    return BertModel.from_pretrained('bert-large-cased')

def bert_tokenizer_base_uncased():
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    return tokenizer

def bert_tokenizer_base_cased():
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')
    return tokenizer

def bert_tokenizer_large_uncased():
    tokenizer = BertTokenizer.from_pretrained('bert-large-uncased')
    return tokenizer

def bert_tokenizer_large_cased():
    tokenizer = BertTokenizer.from_pretrained('bert-large-cased')
    return tokenizer

def kobert_model(path):
    return BertModel.from_pretrained(path)

def kobert_vocab(path):
    return nlp.vocab.BERTVocab.from_sentencepiece(os.path.join(path, "kobert_news_wiki_ko_cased.spiece"), padding_token='[PAD]')

def kobert_tokenizer(path, lower=False):
    vocab = kobert_vocab(path)
    return nlp.data.BERTSPTokenizer(os.path.join(path, "kobert_news_wiki_ko_cased.spiece"), vocab, lower=lower)



PRETRAINED_MODEL = {
    'bert_base_uncased':bert_base_uncased(),
    'bert_base_cased':bert_base_cased(),
    'bert_large_uncased':bert_large_uncased(),
    'bert_large_cased':bert_large_cased(),
}

def classification_with_pretrained_bert(pretrained_model='bert_base_uncased', hidden=768, num_classes=2, dropout=0.4):    
    bert = PRETRAINED_MODEL[pretrained_model]
    return BERTClassification(bert, hidden=hidden, num_classes=num_classes, dropout=dropout)

def sentiment_analysis_with_pretrained_bert(pretrained_model='bert_base_uncased', hidden=768, num_classes=2, dropout=0.4):    
    bert = PRETRAINED_MODEL[pretrained_model]
    return BERTSentimentAnalysis(bert, hidden=hidden, num_classes=num_classes, dropout=dropout)

def sentiment_analysis_with_pretrained_kobert(path='/home/ubuntu/yha/MLops_v2/working/config_yaml/YoungHoonAhn/kobert/kobert_from_pretrained', hidden=768, num_classes=2, dropout=0.4):    
    bert = kobert_model(path)
    return BERTSentimentAnalysis(bert, hidden=hidden, num_classes=num_classes, dropout=dropout)

def question_answering_with_pretrained_bert(pretrained_model='bert_large_cased', hidden=1024, num_classes=2, dropout=0.4):    
    bert = PRETRAINED_MODEL[pretrained_model]
    return BERTQuestionAnswering(bert, hidden=hidden, num_classes=num_classes, dropout=dropout)


def language_modeling_with_pretrained_bert(pretrained_model='bert_base_uncased', hidden=768, vocab_size=30522, dropout=0.4):
    bert = PRETRAINED_MODEL[pretrained_model]
    return BERTLM(bert, vocab_size=vocab_size, hidden=hidden, dropout=dropout)


if __name__ == '__main__':
    model = sentiment_analysis_with_pretrained_kobert()
    print(model)
def UserModel(**kwargs):
	return sentiment_analysis_with_pretrained_bert(**{'num_classes': 2})
