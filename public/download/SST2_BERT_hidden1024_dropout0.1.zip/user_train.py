
import argparse

import pytorch_lightning as pl
from pytorch_lightning.core.saving import save_hparams_to_yaml
from pytorch_lightning.loggers import TensorBoardLogger
from torch.utils.data import DataLoader

from aiscli.load import load_callbacks
from user_lightning_model import UserLightningModule
from user_datamodule import UserDataModule

TRAINER_HPARAMS = {'num_processes': 1, 'gpus': [0], 'auto_select_gpus': False, 'track_grad_norm': -1, 'check_val_every_n_epoch': 1, 'fast_dev_run': False, 'accumulate_grad_batches': 1, 'max_epochs': 10, 'min_epochs': 1, 'precision': 32, 'weights_summary': 'top', 'auto_lr_find': False, 'auto_scale_batch_size': False, 'move_metrics_to_cpu': False}

if __name__ == '__main__':
    model = UserLightningModule()
    datamodule = UserDataModule()
    callbacks = load_callbacks(['ProgressLoggingCallback'], 123123)
    trainer = pl.Trainer(callbacks=callbacks, **TRAINER_HPARAMS)
    trainer.fit(model, datamodule)
